<form action="<?php echo esc_url(get_home_url('/'))?>" class="search-form">
	<div class="form-group">
		<input type="text" name="s" class="form-control" placeholder="<?php echo esc_attr__('Search','aapside');?>">
	</div>
	<button class="submit-btn" type="submit"><i class="fa fa-search"></i></button>
</form>